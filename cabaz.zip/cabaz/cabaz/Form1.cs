﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cabaz
{
    public partial class ASSIGNMENT : Form
    {
        public ASSIGNMENT()
        {
            InitializeComponent();
        }

        private void id_Click(object sender, EventArgs e)
        {

        }

        private void cheack_Click(object sender, EventArgs e)
        {
            // Declaring variables

                string std_name, courses = " ", fullstdinfo, Extra = " ", gender = " ";
                int std_age, std_id;
                // initialing student name from input textbox
                double num;
                std_name = stdNametextBox.Text;

                if (double.TryParse(stdNametextBox.Text, out num))
                {
                    MessageBox.Show("invalid name!");

                    return;
                }
                // validating and parsing for id_textbox  using try parse
                if (int.TryParse(idtext.Text, out std_id))
                {
                    /// MessageBox.Show("succes");
                }
                else
                {
                    MessageBox.Show("waxan lambar ahayn lama ogolo");
                }
                // validating and parsing for  age_textbox using int.parse and conditions
                std_age = int.Parse(agetextbox.Text);
                if (std_age >= 18 & std_age <= 35)
                {
                    //  MessageBox.Show("succes");

                }
                else
                {
                    MessageBox.Show("so geli inta u dhaxayso 18 ilaa 35");
                    return
                    ;
                }


                // male and radio checked
                if (male.Checked)
                {
                    gender = "male ";
                }
                else if (female.Checked)
                {
                    gender = "female";
                }
                else
                {
                    MessageBox.Show("wa inaad dorata mid ka kid ah jinsiga");
                }

              

                // list box 
                if (subjectlist.SelectedIndex != -1)
                {
                    courses = subjectlist.SelectedItem.ToString();
                }
                else {
                    MessageBox.Show("so dooro course");
                }
                // Extra_curricular checked 
                if (extera.Checked)
                {
                    Extra = " yes";


                }
                else
                {
                    Extra = "no";

                }

              





                fullstdinfo = "Name: " + std_name + " \n  ID: " + std_id + "\n  Age: " + std_age + "\n  Gender: " + gender + "\n   Extra_curricular:  " + Extra + "\n   courses:" + courses;
                resultlabel.Text = fullstdinfo;
                

                stdNametextBox.Focus();
          

        }

        private void delet_Click(object sender, EventArgs e)
        {
            stdNametextBox.Text = "";
            idtext.Text = "";
            agetextbox.Text = "";
            male.Checked = false;
            female.Checked = false;
            extera.Checked = false;
            resultlabel.Text = "";
            subjectlist.ClearSelected();
        }

        private void off_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    
        }
    }


