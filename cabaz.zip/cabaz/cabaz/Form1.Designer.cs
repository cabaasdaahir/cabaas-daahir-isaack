﻿namespace cabaz
{
    partial class ASSIGNMENT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.STUDENTINFO = new System.Windows.Forms.GroupBox();
            this.agetextbox = new System.Windows.Forms.TextBox();
            this.female = new System.Windows.Forms.RadioButton();
            this.male = new System.Windows.Forms.RadioButton();
            this.idtext = new System.Windows.Forms.TextBox();
            this.stdNametextBox = new System.Windows.Forms.TextBox();
            this.age = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.subjectlist = new System.Windows.Forms.ListBox();
            this.submit = new System.Windows.Forms.Button();
            this.delet = new System.Windows.Forms.Button();
            this.off = new System.Windows.Forms.Button();
            this.resultlabel = new System.Windows.Forms.Label();
            this.extera = new System.Windows.Forms.CheckBox();
            this.photo = new System.Windows.Forms.PictureBox();
            this.STUDENTINFO.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.photo)).BeginInit();
            this.SuspendLayout();
            // 
            // STUDENTINFO
            // 
            this.STUDENTINFO.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.STUDENTINFO.Controls.Add(this.agetextbox);
            this.STUDENTINFO.Controls.Add(this.female);
            this.STUDENTINFO.Controls.Add(this.male);
            this.STUDENTINFO.Controls.Add(this.idtext);
            this.STUDENTINFO.Controls.Add(this.stdNametextBox);
            this.STUDENTINFO.Controls.Add(this.age);
            this.STUDENTINFO.Controls.Add(this.id);
            this.STUDENTINFO.Controls.Add(this.name);
            this.STUDENTINFO.Location = new System.Drawing.Point(112, 112);
            this.STUDENTINFO.Name = "STUDENTINFO";
            this.STUDENTINFO.Size = new System.Drawing.Size(306, 227);
            this.STUDENTINFO.TabIndex = 1;
            this.STUDENTINFO.TabStop = false;
            // 
            // agetextbox
            // 
            this.agetextbox.Location = new System.Drawing.Point(151, 112);
            this.agetextbox.Name = "agetextbox";
            this.agetextbox.Size = new System.Drawing.Size(131, 26);
            this.agetextbox.TabIndex = 2;
            // 
            // female
            // 
            this.female.AutoSize = true;
            this.female.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.female.Location = new System.Drawing.Point(186, 177);
            this.female.Name = "female";
            this.female.Size = new System.Drawing.Size(89, 26);
            this.female.TabIndex = 4;
            this.female.TabStop = true;
            this.female.Text = "female";
            this.female.UseVisualStyleBackColor = true;
            // 
            // male
            // 
            this.male.AutoSize = true;
            this.male.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.male.Location = new System.Drawing.Point(61, 177);
            this.male.Name = "male";
            this.male.Size = new System.Drawing.Size(74, 26);
            this.male.TabIndex = 3;
            this.male.TabStop = true;
            this.male.Text = "male";
            this.male.UseVisualStyleBackColor = true;
            // 
            // idtext
            // 
            this.idtext.Location = new System.Drawing.Point(151, 72);
            this.idtext.Name = "idtext";
            this.idtext.Size = new System.Drawing.Size(131, 26);
            this.idtext.TabIndex = 1;
            // 
            // stdNametextBox
            // 
            this.stdNametextBox.Location = new System.Drawing.Point(151, 38);
            this.stdNametextBox.Name = "stdNametextBox";
            this.stdNametextBox.Size = new System.Drawing.Size(131, 26);
            this.stdNametextBox.TabIndex = 0;
            // 
            // age
            // 
            this.age.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.age.Location = new System.Drawing.Point(6, 118);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(123, 20);
            this.age.TabIndex = 4;
            this.age.Text = "student age";
            // 
            // id
            // 
            this.id.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.id.Location = new System.Drawing.Point(12, 75);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(100, 23);
            this.id.TabIndex = 4;
            this.id.Text = "student id";
            this.id.Click += new System.EventHandler(this.id_Click);
            // 
            // name
            // 
            this.name.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(6, 38);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(123, 23);
            this.name.TabIndex = 3;
            this.name.Text = "student name";
            // 
            // subjectlist
            // 
            this.subjectlist.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.subjectlist.FormattingEnabled = true;
            this.subjectlist.ItemHeight = 20;
            this.subjectlist.Items.AddRange(new object[] {
            "Java",
            "C#",
            "HTML & CSS3",
            "REACT"});
            this.subjectlist.Location = new System.Drawing.Point(128, 345);
            this.subjectlist.Name = "subjectlist";
            this.subjectlist.Size = new System.Drawing.Size(252, 124);
            this.subjectlist.TabIndex = 5;
            // 
            // submit
            // 
            this.submit.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.submit.Location = new System.Drawing.Point(166, 470);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(75, 36);
            this.submit.TabIndex = 7;
            this.submit.Text = "s&ubmit";
            this.submit.UseVisualStyleBackColor = false;
            this.submit.Click += new System.EventHandler(this.cheack_Click);
            // 
            // delet
            // 
            this.delet.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.delet.Location = new System.Drawing.Point(287, 470);
            this.delet.Name = "delet";
            this.delet.Size = new System.Drawing.Size(75, 36);
            this.delet.TabIndex = 8;
            this.delet.Text = "c&lear";
            this.delet.UseVisualStyleBackColor = false;
            this.delet.Click += new System.EventHandler(this.delet_Click);
            // 
            // off
            // 
            this.off.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.off.Location = new System.Drawing.Point(406, 470);
            this.off.Name = "off";
            this.off.Size = new System.Drawing.Size(75, 36);
            this.off.TabIndex = 9;
            this.off.Text = "e&xit";
            this.off.UseVisualStyleBackColor = false;
            this.off.Click += new System.EventHandler(this.off_Click);
            // 
            // resultlabel
            // 
            this.resultlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultlabel.Location = new System.Drawing.Point(112, 527);
            this.resultlabel.Name = "resultlabel";
            this.resultlabel.Size = new System.Drawing.Size(503, 190);
            this.resultlabel.TabIndex = 6;
            // 
            // extera
            // 
            this.extera.AutoSize = true;
            this.extera.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.extera.Font = new System.Drawing.Font("Microsoft YaHei UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extera.Location = new System.Drawing.Point(443, 406);
            this.extera.Name = "extera";
            this.extera.Size = new System.Drawing.Size(160, 26);
            this.extera.TabIndex = 6;
            this.extera.Text = "extra-curricular";
            this.extera.UseVisualStyleBackColor = false;
            // 
            // photo
            // 
            this.photo.BackgroundImage = global::cabaz.Properties.Resources._0bf4ddb2_6229_4df6_a23c_ee9610a1e23f;
            this.photo.Image = global::cabaz.Properties.Resources._0bf4ddb2_6229_4df6_a23c_ee9610a1e23f1;
            this.photo.Location = new System.Drawing.Point(152, 12);
            this.photo.Name = "photo";
            this.photo.Size = new System.Drawing.Size(197, 94);
            this.photo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.photo.TabIndex = 0;
            this.photo.TabStop = false;
            // 
            // ASSIGNMENT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1314, 726);
            this.Controls.Add(this.extera);
            this.Controls.Add(this.resultlabel);
            this.Controls.Add(this.off);
            this.Controls.Add(this.delet);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.subjectlist);
            this.Controls.Add(this.STUDENTINFO);
            this.Controls.Add(this.photo);
            this.Name = "ASSIGNMENT";
            this.Text = "Form1";
            this.STUDENTINFO.ResumeLayout(false);
            this.STUDENTINFO.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.photo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox photo;
        private System.Windows.Forms.GroupBox STUDENTINFO;
        private System.Windows.Forms.TextBox agetextbox;
        private System.Windows.Forms.TextBox idtext;
        private System.Windows.Forms.TextBox stdNametextBox;
        private System.Windows.Forms.Label age;
        private System.Windows.Forms.Label id;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ListBox subjectlist;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.Button delet;
        private System.Windows.Forms.Button off;
        private System.Windows.Forms.Label resultlabel;
        private System.Windows.Forms.RadioButton male;
        private System.Windows.Forms.RadioButton female;
        private System.Windows.Forms.CheckBox extera;
    }
}

